@extends('layouts.app')

@section('content')
    <div class="container mx-auto mt-8">
        @livewire('contact-submissions-table')
    </div>
@endsection
